public class practiseCiklus {
    public static void main(String[] args) {
        int iterator = 0;
        while (iterator < 3) {
            System.out.println("Hello");
            iterator++;
        }
        System.out.println("Examples end");
    }
}
