public class forCycle {
    public static void main(String[] args) {
        for(int cycleVar = 6;cycleVar>=0;cycleVar-=2){
            System.out.println("Iteration.");
        }
        System.out.println("Program end.");
    }
}
