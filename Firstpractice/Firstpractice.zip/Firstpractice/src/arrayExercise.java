import java.util.Arrays;

public class arrayExercise {
    public static void main(String[] args) {
        /*
        String [] second = new String[3];
        String[]  third = {"Alma", "Körte"};
        second[0] ="Kutya";
        second [1] = "Macska";
        second [1] = "Hal";
        second [2] = "Béka";
        second [3] = "Kacsa";
        System.out.println(second.length);
        System.out.println(second [1]); */



        int[] numbers = new int[3];
        String[] animals = {"dog", "cat", "fish"};
        for(int i = 0; i < numbers.length; i++)
        {;
            System.out.println(animals[i]);
        }
    }
}
