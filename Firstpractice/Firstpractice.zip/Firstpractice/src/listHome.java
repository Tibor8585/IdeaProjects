import java.util.ArrayList;
import java.util.List;

public class listHome {
    List<String> randomNames = new ArrayList<>();

}
