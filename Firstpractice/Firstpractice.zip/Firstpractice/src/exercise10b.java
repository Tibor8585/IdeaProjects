public class exercise10b {
    public static void main(String[] args) {
        int result = 1;
        for(int number = 1; number<=10; number++){
            result = result*number;
        }
        System.out.println("Result: " + result);
    }
}
