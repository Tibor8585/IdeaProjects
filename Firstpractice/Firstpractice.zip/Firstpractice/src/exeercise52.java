public class exeercise52 {
    public static void main(String[] args) {

    }
}
