import java.util.Random;
import java.util.Scanner;

public class practiseDowhileCycle {
    public static void main(String[] args) {
        int iterator = 0;
        do {
            System.out.println("Hello");
            iterator++;
        }while(iterator <3);
    }

}
