public class practiseMethod {
    //metódus a mainben nem szerepelhet
    public static void vonal(){

    }
    public static void main(String[] args) {

    vonal();
    vonal();
    vonal();
    }
}
