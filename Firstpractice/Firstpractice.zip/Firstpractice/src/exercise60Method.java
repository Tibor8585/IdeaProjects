public class exercise60Method {
    public static void main(String[] args) {
        greeting();
        greeting();
        greeting();
    }
    public static void greeting(){
        System.out.println("Have a nice day!");
    }
}
