public class exercise30 {
    public static void main(String[] args) {
        String[] week = {"hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat", "vasárnap"};
        // week[6]="Joker";
        for (int t = 0; t<week.length; t++) {
            System.out.println(week[t]);
        }
        System.out.println(week[4]);
    }
}

