import java.util.HashMap;
import java.util.Map;

public class home {
    public static void main(String[] args) {
        int[] bla=new int[5];
        bla[0]=1;
        bla[2]=3;
        bla[3]=4;
        bla[4]=5;


        int sum=bla[4]+bla[2];
        System.out.println(sum);
        Map<String, Integer>book=new HashMap<>();
        
    }
}
