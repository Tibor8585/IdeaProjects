public class exercise09 {
    public static void main(String[] args) {
        int a = 0;
        while(a <= 20){
            System.out.println("Number: " + a + " " + "square: " + a*a);
            a++;
        }
    }
    }


