public class exercise40 {
}
