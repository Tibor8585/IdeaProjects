import java.util.Random;

public class exercise4 {
    public static void main(String[] args) {
        Random random = new Random();
        int randomNumber = random.nextInt(5);
        System.out.println(randomNumber);
    }
}
