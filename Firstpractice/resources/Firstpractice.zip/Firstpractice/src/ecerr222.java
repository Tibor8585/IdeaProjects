public class ecerr222 {
    public static void main(String[] args) {
        int i=0;
        while(i<4){
            System.out.println("Hello");
            i++;
        }
        String[] array=new String[3];
        System.out.println(array.length-1);
    }
}
