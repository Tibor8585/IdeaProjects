public class exercise74 {
    public static void main(String[] args) {
        String input = "1376367";
        int itemCount = Integer.parseInt(input.substring(6));

    }

    }