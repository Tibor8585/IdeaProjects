import java.util.ArrayList;
import java.util.List;

public class exercise37 {
    public static void main(String[] args) {
        List<String> favFruits = new ArrayList<>();
        favFruits.add("Alma");
        favFruits.add("Banán");
        for(String fruite: favFruits){
            System.out.println(fruite);
        }
    }
}
