public class selectionPractise {
    public static void main(String[] args) {
        boolean variableInit = true;
        if (variableInit){
            int variable = 21;
        }else {
            int variable;
        }
    }
}
