public class exercise9b {
    public static void main(String[] args) {
        for (int a = 0; a <= 20; a++){
            System.out.println("Number: " + a + " " + "square: " + a*a);
        }
    }
}
